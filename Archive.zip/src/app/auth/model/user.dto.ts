export interface UserDto {
    readonly id?: string;
    username?: string;
    fistName?: string;
    middleName?: string;
    lastName?: string;
    farmName?: string;
    phoneNumber?: string;
    email?: string;
    password: string;
    token?: string;
}
