import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportsmain',
  templateUrl: './reportsmain.component.html',
  styleUrls: ['./reportsmain.component.css']
})
export class ReportsmainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
