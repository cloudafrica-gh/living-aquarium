import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-profile-details',
  templateUrl: './project-profile-details.component.html',
  styleUrls: ['./project-profile-details.component.css']
})
export class ProjectProfileDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
