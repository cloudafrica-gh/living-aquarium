import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-profile-edit',
  templateUrl: './project-profile-edit.component.html',
  styleUrls: ['./project-profile-edit.component.css']
})
export class ProjectProfileEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
