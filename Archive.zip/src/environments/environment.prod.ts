export const environment = {
  production: true,
  dafaServer: 'http://api.cloud-africa.io/api',
  laServer: 'http://157.230.150.194:8443/api'
};
